from django.shortcuts import render
from django.core.mail import EmailMessage

def send_email(request):
    if request.method == 'POST':
        to_email = request.POST.get('to')
        cc = request.POST.get('cc', '')
        bcc = request.POST.get('bcc', '')
        subject = request.POST.get('subject')
        message = request.POST.get('message')

        cc_list = [x.strip() for x in cc.split(',') if x.strip()]
        bcc_list = [x.strip() for x in bcc.split(',') if x.strip()]

        email = EmailMessage(
            subject=subject,
            body=message,
            from_email='yourgmail@gmail.com',
            to=[to_email],
            cc=cc_list,
            bcc=bcc_list,
        )

        email.send()

        return render(request, 'email_form.html', {'success': True})

    return render(request, 'email_form.html')
